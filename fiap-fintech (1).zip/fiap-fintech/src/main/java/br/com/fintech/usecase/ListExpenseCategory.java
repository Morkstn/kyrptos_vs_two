package br.com.fintech.usecase;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.com.fintech.dao.ExpenseCategoryDao;
import br.com.fintech.bean.ExpenseCategory;
import br.com.fintech.bean.User;
import br.com.fintech.connection.ConnectionFactory;

public class ListExpenseCategory implements UseCase {
	private ExpenseCategoryDao dao = new ExpenseCategoryDao(ConnectionFactory.getConnection());
	
	public void execute(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		HttpSession session = req.getSession();
		User user = (User)session.getAttribute("userLogged");
		
		List<ExpenseCategory> categories = this.dao.read(user);
	
		req.setAttribute("expenseCategories", categories);
	}
}
