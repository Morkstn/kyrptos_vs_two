package br.com.fintech.usecase;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.fintech.dao.UserDao;
import br.com.fintech.security.UserPassGen;
import br.com.fintech.bean.User;
import br.com.fintech.connection.ConnectionFactory;

public class CreateUser implements UseCase {

	private UserDao dao = new UserDao(ConnectionFactory.getConnection());

	public void execute(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		String name = req.getParameter("name");
		String last_name = req.getParameter("last_name");
		String gender = req.getParameter("gender");
		String email = req.getParameter("email");
		String password = req.getParameter("password");

		UUID uuid = UUID.randomUUID();
		User user = new User(uuid.toString(), name, last_name, gender, email, password, null, null, null, null);

		try {
			boolean status = UserPassGen.signUp(user, ConnectionFactory.getConnection());
			if(status) {
				res.sendRedirect("login");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		req.setAttribute("user", user);

		System.out.println("User creted!");
	}
}
