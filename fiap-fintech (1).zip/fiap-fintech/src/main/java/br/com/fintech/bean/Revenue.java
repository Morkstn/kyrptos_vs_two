package br.com.fintech.bean;

import java.io.Serializable;
import java.sql.Date;

public class Revenue implements Serializable {
	private static final long serialVersionUID = 3L;
	private Integer COD_RECEITA;
	private String COD_USUARIO;
	private String COD_CATEGORIA_RECEITA;
	private String NOM_RECEITA;
	private double DS_VALOR;
	private Date DS_DATA;

	public Revenue(Integer cOD_RECEITA, String cOD_USUARIO, String cOD_CATEGORIA_RECEITA, String nOM_RECEITA,
			double dS_VALOR, Date dS_DATA) {
		super();
		COD_RECEITA = cOD_RECEITA;
		COD_USUARIO = cOD_USUARIO;
		COD_CATEGORIA_RECEITA = cOD_CATEGORIA_RECEITA;
		NOM_RECEITA = nOM_RECEITA;
		DS_VALOR = dS_VALOR;
		DS_DATA = dS_DATA;
	}

	public Integer getCOD_RECEITA() {
		return COD_RECEITA;
	}

	public void setCOD_RECEITA(Integer cOD_RECEITA) {
		COD_RECEITA = cOD_RECEITA;
	}

	public String getCOD_USUARIO() {
		return COD_USUARIO;
	}

	public void setCOD_USUARIO(String cOD_USUARIO) {
		COD_USUARIO = cOD_USUARIO;
	}

	public String getCOD_CATEGORIA_RECEITA() {
		return COD_CATEGORIA_RECEITA;
	}

	public void setCOD_CATEGORIA_RECEITA(String cOD_CATEGORIA_RECEITA) {
		COD_CATEGORIA_RECEITA = cOD_CATEGORIA_RECEITA;
	}

	public Revenue() {

	}

	public String getNOM_RECEITA() {
		return NOM_RECEITA;
	}

	public void setNOM_RECEITA(String nOM_RECEITA) {
		NOM_RECEITA = nOM_RECEITA;
	}

	public double getDS_VALOR() {
		return DS_VALOR;
	}

	public void setDS_VALOR(double dS_VALOR) {
		DS_VALOR = dS_VALOR;
	}

	public Date getDS_DATA() {
		return DS_DATA;
	}

	public void setDS_DATA(Date dS_DATA) {
		DS_DATA = dS_DATA;
	}

	@Override
	public String toString() {
		return "{'COD_USUARIO':'" + this.COD_USUARIO + "', 'COD_RECEITA':'" + this.COD_RECEITA
				+ "', 'COD_CATEGORIA_RECEITA':'" + this.COD_CATEGORIA_RECEITA + "', 'NOM_RECEITA':'" + this.NOM_RECEITA
				+ "', 'DS_VALOR':'" + this.DS_VALOR + "', 'DS_DATA':'" + this.DS_DATA.getTime() + "'}";
	}

}
