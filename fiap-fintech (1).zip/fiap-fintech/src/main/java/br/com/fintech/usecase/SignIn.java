package br.com.fintech.usecase;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.com.fintech.dao.UserDao;
import br.com.fintech.security.UserPassGen;
import br.com.fintech.bean.User;
import br.com.fintech.connection.ConnectionFactory;

public class SignIn implements UseCase {

	public void execute(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		String email = req.getParameter("email");
		String password = req.getParameter("password");

		

		try {
			User user = UserPassGen.authenticateUser(email, password, ConnectionFactory.getConnection());
			if (user == null) {
				res.sendError(403, "Invalid Credentials.");
			}

			// System.out.printf("user not null",user);
			HttpSession session = req.getSession();
			session.setAttribute("userLogged", user);
//			session.setAttribute("userLogged", user);
			res.sendRedirect("dashboard");
			System.out.println("User signined!");

		} catch (IOException e) {
			
			res.sendError(404, "Invalid Credentials. erro IO"+ e.getMessage());
		} catch (Exception e) {
			
			res.sendError(404, "Invalid Credentials." + e.getMessage());
		}

	}
}
