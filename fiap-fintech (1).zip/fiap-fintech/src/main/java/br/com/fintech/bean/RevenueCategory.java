package br.com.fintech.bean;

import java.io.Serializable;

public class RevenueCategory implements Serializable{
	private static final long serialVersionUID = 2L;
	private String COD_CATEGORIA_RECEITA;
	private String DS_CATEGORIA_RECEITA;
	
	
	public RevenueCategory(String cOD_CATEGORIA_RECEITA, String dS_CATEGORIA_RECEITA) {
		
		setCOD_CATEGORIA_RECEITA(cOD_CATEGORIA_RECEITA);
		setDS_CATEGORIA_RECEITA(dS_CATEGORIA_RECEITA);
	}
public RevenueCategory() {
		
	}
	public String getDS_CATEGORIA_RECEITA() {
		return DS_CATEGORIA_RECEITA;
	}
	public void setDS_CATEGORIA_RECEITA(String dS_CATEGORIA_RECEITA) {
		DS_CATEGORIA_RECEITA = dS_CATEGORIA_RECEITA;
	}
	
	public String getCOD_CATEGORIA_RECEITA() {
		return COD_CATEGORIA_RECEITA;
	}
	public void setCOD_CATEGORIA_RECEITA(String cOD_CATEGORIA_RECEITA) {
		COD_CATEGORIA_RECEITA = cOD_CATEGORIA_RECEITA;
	}

}
