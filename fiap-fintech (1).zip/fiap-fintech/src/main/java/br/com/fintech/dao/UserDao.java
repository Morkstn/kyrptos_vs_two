package br.com.fintech.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.fintech.bean.User;
import br.com.fintech.connection.ConnectionFactory;

public class UserDao implements GenericDAO<User> {

	public static List<User> list = new ArrayList<>();

//	static {
//		UUID uuid = UUID.randomUUID();
//
//		String name = "Anderson";
//		String last_name = "Anderson";
//		String gender = "Masculino";
//		String email = "anderson@mail.com";
//		String password = "123456@";
//
//		User userOne = new User(uuid.toString(), name, last_name, gender, email, password);
//
//		name = "Italo";
//		last_name = "Italo";
//		gender = "Masculino";
//		email = "italo@mail.com";
//		password = "123456@";
//
//		User userTwo = new User(uuid.toString(), name, last_name, gender, email, password);
//
//		name = "Moraci";
//		last_name = "Moraci";
//		gender = "Masculino";
//		email = "moraci@mail.com";
//		password = "123456@";
//
//		User userThree = new User(uuid.toString(), name, last_name, gender, email, password);
//
//		name = "Joao";
//		last_name = "Joao";
//		gender = "Masculino";
//		email = "joao@mail.com";
//		password = "123456@";
//
//		User userFour = new User(uuid.toString(), name, last_name, gender, email, password);
//
//		name = "Tayna";
//		last_name = "Tayna";
//		gender = "Feminino";
//		email = "tayna@mail.com";
//		password = "123456@";
//
//		User userFive = new User(uuid.toString(), name, last_name, gender, email, password);
//
//		UserDao.list.add(userOne);
//		UserDao.list.add(userTwo);
//		UserDao.list.add(userThree);
//		UserDao.list.add(userFour);
//		UserDao.list.add(userFive);
//	}

	private Connection Conn;

	public UserDao(Connection conn) {
		this.Conn = conn;
	}

	public User findByEmail(String email) {

		PreparedStatement stmt = null;

		ResultSet result = null;

		try {

			stmt = this.Conn.prepareStatement("SELECT * FROM T_SFF_USUARIO where DS_EMAIL = ?");
			stmt.setString(1, email);

			result = stmt.executeQuery();
//			System.out.println(result);

			if (result.next()) {

				User user = new User();

				user.setNOM_USUARIO(result.getString("NOM_USUARIO"));
				user.setDS_SOBRENOME_USUARIO(result.getString("DS_SOBRENOME_USUARIO"));
				user.setDS_GENERO(result.getString("DS_GENERO"));
				user.setDS_SENHA(result.getString("DS_SENHA"));
				user.setCOD_USUARIO(result.getString("COD_USUARIO"));
				user.setDS_SALT(result.getString("DS_SALT"));
				user.setDS_EMAIL(result.getString("DS_EMAIL"));

				return user;
			}
		} catch (SQLException e) {
			throw new RuntimeException("Erro ao consultar a base de dados", e);
		} finally {

			ConnectionFactory.closeConnection(this.Conn, stmt, result);

		}
		return null;
	}

	@Override
	public void create(User o) {
		PreparedStatement stmt = null;
//		ResultSet result = null;
		try {
			stmt = this.Conn.prepareStatement("INSERT INTO T_SFF_USUARIO (COD_USUARIO," + " NOM_USUARIO,"
					+ " DS_SOBRENOME_USUARIO," + " DS_GENERO," + " DS_EMAIL," + " DS_SENHA," + "DS_SALT,"
					+ "DS_SALARIO," + "DS_PROFISSAO," + "DS_ESTADO_CIVIL) values (" + "?," + "?," + "?," + "?," + "?,"
					+ "?," + "?," + "null," + "null," + "null)");
			stmt.setString(1, o.getCOD_USUARIO());
			stmt.setString(2, o.getNOM_USUARIO());
			stmt.setString(3, o.getDS_SOBRENOME_USUARIO());
			stmt.setString(4, o.getDS_GENERO());
			stmt.setString(5, o.getDS_EMAIL());
			stmt.setString(6, o.getDS_SENHA());
			stmt.setString(7, o.getDS_SALT());
			stmt.executeUpdate();

		} catch (SQLException e) {

			Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, e);
		} finally {
			ConnectionFactory.closeConnection(this.Conn, stmt);
		}

	}

	@Override
	public void update(User o) {
		PreparedStatement stmt = null;
		ResultSet result = null;
		try {
			String query = "UPDATE T_SFF_USUARIO ";
			query.concat("SET NOM_USUARIO = ? ");
			query.concat("SET DS_SOBRENOME_USUARIO = ? ");
			query.concat("SET DS_GENERO = ? ");
			query.concat("SET DS_SENHA = ? ");
			query.concat("SET DS_SALARIO = ? ");
			query.concat("SET DS_PROFISSAO = ? ");
			query.concat("SET DS_ESTADO_CIVIL = ? ");
			query.concat("WHERE COD_USUARIO = ?  ");

			stmt = this.Conn.prepareStatement(query);

			stmt.setString(1, o.getNOM_USUARIO());
			stmt.setString(2, o.getDS_SOBRENOME_USUARIO());
			stmt.setString(3, o.getDS_GENERO());
			stmt.setString(4, o.getDS_SENHA());
			stmt.setDouble(5, o.getDS_SALARIO());
			stmt.setString(6, o.getDS_ESTADO_CIVIL());
			stmt.setString(7, o.getDS_PROFISSAO());
			stmt.setString(8, o.getCOD_USUARIO());

			stmt.executeUpdate();

		} catch (SQLException e) {

			Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, e);
		} finally {
			ConnectionFactory.closeConnection(this.Conn, stmt, result);
		}

		return;

	}

	@Override
	public void delete(int id) {
		PreparedStatement stmt = null;

		ResultSet result = null;

		try {

			stmt = this.Conn.prepareStatement("DELETE  FROM T_SFF_USUARIO where COD_USUARIO = ?");
			stmt.setInt(1, id);

			stmt.executeUpdate();

		} catch (SQLException e) {
			throw new RuntimeException("Erro ao consultar a base de dados", e);
		} finally {

			ConnectionFactory.closeConnection(this.Conn, stmt, result);

		}

	}

	@Override
	public List<User> read(User o) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
