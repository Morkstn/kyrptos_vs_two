package br.com.fintech.usecase;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.com.fintech.dao.RevenueCategoryDao;
import br.com.fintech.bean.RevenueCategory;
import br.com.fintech.bean.User;
import br.com.fintech.connection.ConnectionFactory;

public class CreateRevenueCategory implements UseCase {
	
	private RevenueCategoryDao dao = new RevenueCategoryDao(ConnectionFactory.getConnection());
	
	public void execute(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		HttpSession session = req.getSession();
		User user = (User) session.getAttribute("userLogged");
		if (user == null) {
			session.invalidate();
			res.sendRedirect(req.getContextPath()+"/login");
		}
		
		String name = req.getParameter("name");
		
		
		UUID uuid = UUID.randomUUID();
		
		RevenueCategory category = new RevenueCategory(uuid.toString(),name);
		

		this.dao.create(category); 
                      
        System.out.println("Category creted!");
        
	}
}
