package br.com.fintech.bean;

import java.io.Serializable;
import java.sql.Date;

public class Expense implements Serializable {
	private static final long serialVersionUID = 5L;
	private String COD_USUARIO;
	private String COD_CATEGORIA_DESPESA;
	private String COD_DESPESA;
	private String NOM_DESPESA;
	private double DS_VALOR;
	private Date DS_DATA;

	public Expense() {

	}

	public Expense(String cOD_USUARIO,String cOD_DESPESA,  String cOD_CATEGORIA_DESPESA, String nOM_DESPESA,
			double dS_VALOR, Date dS_DATA) {

		COD_USUARIO = cOD_USUARIO;
		COD_CATEGORIA_DESPESA = cOD_CATEGORIA_DESPESA;
		COD_DESPESA = cOD_DESPESA;
		NOM_DESPESA = nOM_DESPESA;
		DS_VALOR = dS_VALOR;
		DS_DATA = dS_DATA;
	}

	public String getCOD_USUARIO() {
		return COD_USUARIO;
	}

	public void setCOD_USUARIO(String cOD_USUARIO) {
		COD_USUARIO = cOD_USUARIO;
	}

	public String getCOD_CATEGORIA_DESPESA() {
		return COD_CATEGORIA_DESPESA;
	}

	public void setCOD_CATEGORIA_DESPESA(String cOD_CATEGORIA_DESPESA) {
		COD_CATEGORIA_DESPESA = cOD_CATEGORIA_DESPESA;
	}

	public String getCOD_DESPESA() {
		return COD_DESPESA;
	}

	public void setCOD_DESPESA(String cOD_DESPESA) {
		COD_DESPESA = cOD_DESPESA;
	}

	public String getNOM_DESPESA() {
		return NOM_DESPESA;
	}

	public void setNOM_DESPESA(String nOM_DESPESA) {
		NOM_DESPESA = nOM_DESPESA;
	}

	public double getDS_VALOR() {
		return DS_VALOR;
	}

	public void setDS_VALOR(double dS_VALOR) {
		DS_VALOR = dS_VALOR;
	}

	public Date getDS_DATA() {
		return DS_DATA;
	}

	public void setDS_DATA(Date dS_DATA) {
		DS_DATA = dS_DATA;
	}

}
