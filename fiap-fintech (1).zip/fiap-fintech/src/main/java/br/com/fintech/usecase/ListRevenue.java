package br.com.fintech.usecase;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.com.fintech.dao.RevenueDao;
import br.com.fintech.bean.Revenue;
import br.com.fintech.bean.User;
import br.com.fintech.connection.ConnectionFactory;

public class ListRevenue implements UseCase {
	
	private RevenueDao dao = new RevenueDao(ConnectionFactory.getConnection());	
	
	public void execute(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		HttpSession session = req.getSession();
		User user = (User)session.getAttribute("userLogged");
		if (user == null) {
			session.invalidate();
			res.sendRedirect(req.getContextPath()+"/login");
		}
		
		
		List<Revenue> revenues = this.dao.read(user);
		req.setAttribute("revenues", revenues);
	}
}
