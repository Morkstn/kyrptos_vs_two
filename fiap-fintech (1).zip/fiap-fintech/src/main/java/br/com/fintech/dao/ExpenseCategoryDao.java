package br.com.fintech.dao;


import java.sql.Connection;
import java.util.List;

import br.com.fintech.bean.ExpenseCategory;
import br.com.fintech.bean.User;

public class ExpenseCategoryDao implements GenericDAO<ExpenseCategory>{
	private Connection Conn;

	public ExpenseCategoryDao(Connection connection) {
		this.Conn = connection;
	}


	@Override
	public ExpenseCategory findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void create(ExpenseCategory o) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(ExpenseCategory o) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<ExpenseCategory> read(User o) {
		// TODO Auto-generated method stub
		return null;
	}


}
