package br.com.fintech.bean;

import java.io.Serializable;

public class ExpenseCategory  implements Serializable{
	
	private static final long serialVersionUID = 4L;

	private String COD_CATEGORIA;

	private String NOM_CATEGORIA;

	public ExpenseCategory() {

	}

	public ExpenseCategory(String cOD_CATEGORIA, String nOM_CATEGORIA) {
		
		COD_CATEGORIA = cOD_CATEGORIA;
		NOM_CATEGORIA = nOM_CATEGORIA;
	}

	public String getCOD_CATEGORIA() {
		return COD_CATEGORIA;
	}

	public void setCOD_CATEGORIA(String cOD_CATEGORIA) {
		COD_CATEGORIA = cOD_CATEGORIA;
	}

	public String getNOM_CATEGORIA() {
		return NOM_CATEGORIA;
	}

	public void setNOM_CATEGORIA(String nOM_CATEGORIA) {
		NOM_CATEGORIA = nOM_CATEGORIA;
	}

}
