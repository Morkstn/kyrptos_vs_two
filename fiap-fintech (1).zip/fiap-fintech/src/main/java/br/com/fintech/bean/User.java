package br.com.fintech.bean;

import java.io.Serializable;

public class User implements Serializable {
	

	private static final long serialVersionUID = 1L;
	private String COD_USUARIO;
	private String NOM_USUARIO;
	private String DS_SOBRENOME_USUARIO;
	private String DS_GENERO;
	private String DS_EMAIL;
	private String DS_SENHA;
	private Double DS_SALARIO;
	private String DS_PROFISSAO;
	private String DS_ESTADO_CIVIL;
	private String DS_SALT;

	public User() {

	}

	

	public User(String cOD_USUARIO, String nOM_USUARIO, String dS_SOBRENOME_USUARIO, String dS_GENERO, String dS_EMAIL,
			String dS_SENHA, Double dS_SALARIO, String dS_PROFISSAO, String dS_ESTADO_CIVIL, String dS_SALT) {
		super();
		COD_USUARIO = cOD_USUARIO;
		NOM_USUARIO = nOM_USUARIO;
		DS_SOBRENOME_USUARIO = dS_SOBRENOME_USUARIO;
		DS_GENERO = dS_GENERO;
		DS_EMAIL = dS_EMAIL;
		DS_SENHA = dS_SENHA;
		DS_SALARIO = dS_SALARIO;
		DS_PROFISSAO = dS_PROFISSAO;
		DS_ESTADO_CIVIL = dS_ESTADO_CIVIL;
		DS_SALT = dS_SALT;
	}



	public String getCOD_USUARIO() {
		return COD_USUARIO;
	}

	public void setCOD_USUARIO(String cOD_USUARIO) {
		COD_USUARIO = cOD_USUARIO;
	}

	public String getNOM_USUARIO() {
		return NOM_USUARIO;
	}

	public void setNOM_USUARIO(String nOM_USUARIO) {
		NOM_USUARIO = nOM_USUARIO;
	}

	public String getDS_SOBRENOME_USUARIO() {
		return DS_SOBRENOME_USUARIO;
	}

	public void setDS_SOBRENOME_USUARIO(String dS_SOBRENOME_USUARIO) {
		DS_SOBRENOME_USUARIO = dS_SOBRENOME_USUARIO;
	}

	public String getDS_GENERO() {
		return DS_GENERO;
	}

	public void setDS_GENERO(String dS_GENERO) {
		DS_GENERO = dS_GENERO;
	}

	public String getDS_EMAIL() {
		return DS_EMAIL;
	}

	public void setDS_EMAIL(String dS_EMAIL) {
		DS_EMAIL = dS_EMAIL;
	}

	public String getDS_SENHA() {
		return DS_SENHA;
	}

	public void setDS_SENHA(String dS_SENHA) {
		DS_SENHA = dS_SENHA;
	}

	public Double getDS_SALARIO() {
		return DS_SALARIO;
	}

	public void setDS_SALARIO(Double dS_SALARIO) {
		DS_SALARIO = dS_SALARIO;
	}

	public String getDS_PROFISSAO() {
		return DS_PROFISSAO;
	}

	public void setDS_PROFISSAO(String dS_PROFISSAO) {
		DS_PROFISSAO = dS_PROFISSAO;
	}

	public String getDS_ESTADO_CIVIL() {
		return DS_ESTADO_CIVIL;
	}

	public void setDS_ESTADO_CIVIL(String dS_ESTADO_CIVIL) {
		DS_ESTADO_CIVIL = dS_ESTADO_CIVIL;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public boolean isValid(String email, String password) {
		if (!this.DS_EMAIL.equals(email))
			return false;
		if (!this.DS_SENHA.equals(password))
			return false;
		return true;
	}

	public String getDS_SALT() {
		return DS_SALT;
	}

	public void setDS_SALT(String dS_SALT) {
		DS_SALT = dS_SALT;
	}
	@Override
	public String toString() {
		return "User:{COD_USUARIO=" + COD_USUARIO 
				+ ", NOM_USUARIO=" + NOM_USUARIO 
				+ ", DS_SOBRENOME_USUARIO="+ DS_SOBRENOME_USUARIO 
				+", DS_GENERO=" + DS_GENERO 
				+ ", DS_EMAIL=" + DS_EMAIL 
				+ ", DS_SENHA="	+ DS_SENHA 
				+ ", DS_SALARIO=" + DS_SALARIO 
				+ ", DS_PROFISSAO=" + DS_PROFISSAO 
				+ ", DS_ESTADO_CIVIL=" + DS_ESTADO_CIVIL 
				+ ", DS_SALT=" + DS_SALT + "}";
	}

}
