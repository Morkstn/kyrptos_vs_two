package br.com.fintech.dao;


import java.sql.Connection;
import java.util.List;
import br.com.fintech.bean.RevenueCategory;
import br.com.fintech.bean.User;

public class RevenueCategoryDao implements GenericDAO<RevenueCategory> {

	private Connection Conn;

	public RevenueCategoryDao(Connection connection) {
		this.Conn = connection;
	}
	@Override
	public void create(RevenueCategory o) {
		// TODO Auto-generated method stub

	}

	@Override
	public void update(RevenueCategory o) {
		// TODO Auto-generated method stub

	}

	@Override
	public RevenueCategory findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<RevenueCategory> read(User o) {
		// TODO Auto-generated method stub
		return null;
	}

}
