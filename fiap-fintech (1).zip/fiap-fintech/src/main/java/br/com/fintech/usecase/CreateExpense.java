package br.com.fintech.usecase;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.com.fintech.dao.ExpenseDao;
import br.com.fintech.bean.Expense;
import br.com.fintech.bean.User;
import br.com.fintech.connection.ConnectionFactory;

public class CreateExpense implements UseCase {

	
	private ExpenseDao dao = new ExpenseDao(ConnectionFactory.getConnection());

	public void execute(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		HttpSession session = req.getSession();
		User user = (User)session.getAttribute("userLogged");
		if (user == null) {
			session.invalidate();
			res.sendRedirect(req.getContextPath()+"/login");
		}
		
		String category_cod = req.getParameter("category_cod");
		String name = req.getParameter("name");
		String amount = req.getParameter("amount");
		Date date = new Date(new java.util.Date().getTime());

		UUID uuid = UUID.randomUUID();
		Expense expense = new Expense(
				user.getCOD_USUARIO(),
				uuid.toString(),
				category_cod,
				name,
				Double.parseDouble(amount), date);

		this.dao.create(expense);
//retornar messagem ao s
		System.out.println("Expense creted!");

	}
}
