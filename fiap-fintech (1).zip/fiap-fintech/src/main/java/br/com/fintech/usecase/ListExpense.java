package br.com.fintech.usecase;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.com.fintech.dao.ExpenseDao;
import br.com.fintech.bean.Expense;
import br.com.fintech.bean.User;
import br.com.fintech.connection.ConnectionFactory;

public class ListExpense implements UseCase {
	private ExpenseDao dao = new ExpenseDao(ConnectionFactory.getConnection());
	
	public void execute(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		HttpSession session = req.getSession();
		User user = (User)session.getAttribute("userLogged");
		
		List<Expense> expenses = this.dao.read(user);
		req.setAttribute("expenses", expenses);
	}
}
