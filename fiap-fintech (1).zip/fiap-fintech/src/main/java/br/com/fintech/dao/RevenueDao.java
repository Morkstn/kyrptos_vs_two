package br.com.fintech.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import br.com.fintech.bean.Revenue;
import br.com.fintech.bean.User;
import br.com.fintech.connection.ConnectionFactory;

public class RevenueDao implements GenericDAO<Revenue> {

	private Connection Conn;

	public RevenueDao(Connection connection) {
		this.Conn = connection;
	}

	@Override
	public void create(Revenue o) {
		PreparedStatement stmt = null;
//		ResultSet result = null;
		try {
			stmt = this.Conn.prepareStatement(
					"Insert into T_SFF_RECEITA (COD_USUARIO,COD_CATEGORIA_RECEITA,NOM_RECEITA,DS_VALOR,DS_DATA,COD_RECEITA) values (?,?,?,?,?,SQ_RECEITAS.NEXTVAL);");
			stmt.setString(1, o.getCOD_USUARIO());
			stmt.setString(2, o.getCOD_CATEGORIA_RECEITA());
			stmt.setString(3, o.getNOM_RECEITA());
			stmt.setDouble(4, o.getDS_VALOR());
			stmt.setDate(5, o.getDS_DATA());
			stmt.executeUpdate();
		} catch (Exception e) {
			Logger.getLogger(RevenueDao.class.getName()).log(Level.SEVERE, null, e);
		}

	}

	public void update(Revenue o) {
		PreparedStatement stmt = null;
		ResultSet result = null;
		try {
			String query = "UPDATE T_SFF_RECEITA ";

//			if (o.getCOD_CATEGORIA_RECEITA() != null) {
			query.concat("SET COD_CATEGORIA_RECEITA = ? ");
//			}
//			if (o.getNOM_RECEITA() != null) {
			query.concat("SET NOM_RECEITA = ? ");
//			}
//			if (o.getDS_VALOR() != 0.0) {
			query.concat("SET DS_VALOR = ? ");
//			}
//			if (o.getDS_DATA() != null) {
			query.concat("SET DS_DATA = ? ");
//			}

			query.concat("WHERE COD_USUARIO = ?  AND COD_RECEITA = ? ");

			stmt = this.Conn.prepareStatement(query);

			stmt.setString(1, o.getCOD_CATEGORIA_RECEITA());
			stmt.setString(2, o.getNOM_RECEITA());
			stmt.setDouble(3, o.getDS_VALOR());
			stmt.setDate(4, o.getDS_DATA());
			stmt.setString(5, o.getCOD_USUARIO());
			stmt.setInt(6, o.getCOD_RECEITA());

			stmt.executeUpdate();

		} catch (SQLException e) {

			Logger.getLogger(RevenueDao.class.getName()).log(Level.SEVERE, null, e);
		} finally {
			ConnectionFactory.closeConnection(this.Conn, stmt, result);
		}

		

	}

	public List<Revenue> read(User o) {

		PreparedStatement stmt = null;
		List<Revenue> lista = new ArrayList<Revenue>();
		ResultSet result = null;

		try {

			stmt = this.Conn.prepareStatement("SELECT * FROM T_SFF_RECEITA where COD_USUARIO = ?");
			stmt.setString(1, o.getCOD_USUARIO());

			result = stmt.executeQuery();

			while (result.next()) {
				Revenue receita = new Revenue();
				receita.setCOD_RECEITA(result.getInt("COD_RECEITA"));
				receita.setCOD_CATEGORIA_RECEITA(result.getString("COD_CATEGORIA_RECEITA"));
				receita.setDS_VALOR(result.getDouble("DS_VALOR"));
				receita.setNOM_RECEITA(result.getString("NOM_RECEITA"));
				receita.setDS_DATA(result.getDate("DS_DATA"));
				receita.setCOD_USUARIO(result.getString("COD_USUARIO"));
				lista.add(receita);

			}
			return lista;
		} catch (SQLException e) {
			throw new RuntimeException("Erro ao consultar a base de dados", e);
		} finally {

			ConnectionFactory.closeConnection(this.Conn, stmt, result);

		}
	}

	@Override
	public Revenue findById(int id) {
		PreparedStatement stmt = null;

		ResultSet result = null;

		try {

			stmt = this.Conn.prepareStatement("SELECT * FROM T_SFF_RECEITA where COD_RECEITA = ?");
			stmt.setInt(1, id);

			result = stmt.executeQuery();

			if (result.first()) {

				Revenue receita = new Revenue();
				receita.setCOD_RECEITA(result.getInt("COD_RECEITA"));
				receita.setCOD_CATEGORIA_RECEITA(result.getString("COD_CATEGORIA_RECEITA"));
				receita.setDS_VALOR(result.getDouble("DS_VALOR"));
				receita.setNOM_RECEITA(result.getString("NOM_RECEITA"));
				receita.setDS_DATA(result.getDate("DS_DATA"));
				receita.setCOD_USUARIO(result.getString("COD_USUARIO"));

				return receita;
			}
		} catch (SQLException e) {
			throw new RuntimeException("Erro ao consultar a base de dados", e);
		} finally {

			ConnectionFactory.closeConnection(this.Conn, stmt, result);

		}
		return null;
	}

	@Override
	public void delete(int id) {
		PreparedStatement stmt = null;

		ResultSet result = null;

		try {

			stmt = this.Conn.prepareStatement("DELETE  FROM T_SFF_RECEITA where COD_RECEITA = ?");
			stmt.setInt(1, id);

			stmt.executeUpdate();

		} catch (SQLException e) {
			throw new RuntimeException("Erro ao consultar a base de dados", e);
		} finally {

			ConnectionFactory.closeConnection(this.Conn, stmt, result);

		}

	}

}
