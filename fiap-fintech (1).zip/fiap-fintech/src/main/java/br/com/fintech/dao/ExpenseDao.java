package br.com.fintech.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import br.com.fintech.bean.Expense;
import br.com.fintech.bean.User;
import br.com.fintech.connection.ConnectionFactory;

public class ExpenseDao implements GenericDAO<Expense> {

	private Connection Conn;

	public ExpenseDao(Connection connection) {
		this.Conn = connection;
	}

//	public List<Revenue> list() {
//		return ExpenseDao.list;
//	}

	@Override
	public void create(Expense o) {
		UUID uuid = UUID.randomUUID();
		PreparedStatement stmt = null;
//		ResultSet result = null;
		try {
			stmt = this.Conn.prepareStatement(
					"Insert into T_SFF_DESPESAS (COD_USUARIO,COD_CATEGORIA_DESPESA,NOM_DESPESA,DS_VALOR,DS_DATA,COD_DESPESA) values (?,?,?,?,?,?);");
			stmt.setString(1, o.getCOD_USUARIO());
			stmt.setString(2, o.getCOD_CATEGORIA_DESPESA());
			stmt.setString(3, o.getNOM_DESPESA());
			stmt.setDouble(4, o.getDS_VALOR());
			stmt.setDate(5, o.getDS_DATA());
			stmt.setString(6, uuid.toString());
			stmt.executeUpdate();
		} catch (Exception e) {
			Logger.getLogger(ExpenseDao.class.getName()).log(Level.SEVERE, null, e);
		}

	}

	public void update(Expense o) {
		PreparedStatement stmt = null;
		ResultSet result = null;
		try {
			String query = "UPDATE T_SFF_DESPESAS ";

//			if (o.getCOD_CATEGORIA_DESPESA() != null) {
			query.concat("SET COD_CATEGORIA_DESPESA = ? ");
//			}
//			if (o.getNOM_DESPESA() != null) {
			query.concat("SET NOM_DESPESA = ? ");
//			}
//			if (o.getDS_VALOR() != 0.0) {
			query.concat("SET DS_VALOR = ? ");
//			}
//			if (o.getDS_DATA() != null) {
			query.concat("SET DS_DATA = ? ");
//			}

			query.concat("WHERE COD_USUARIO = ?  AND COD_DESPESA = ? ");

			stmt = this.Conn.prepareStatement(query);

			stmt.setString(1, o.getCOD_CATEGORIA_DESPESA());
			stmt.setString(2, o.getNOM_DESPESA());
			stmt.setDouble(3, o.getDS_VALOR());
			stmt.setDate(4, o.getDS_DATA());
			stmt.setString(5, o.getCOD_USUARIO());
			stmt.setString(6, o.getCOD_DESPESA());

			stmt.executeUpdate();

		} catch (SQLException e) {

			Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, e);
		} finally {
			ConnectionFactory.closeConnection(this.Conn, stmt, result);
		}

		return;

	}

	public List<Expense> read(User o) {

		PreparedStatement stmt = null;
		List<Expense> lista = new ArrayList<Expense>();
		ResultSet result = null;

		try {

			stmt = this.Conn.prepareStatement("SELECT * FROM T_SFF_DESPESAS where COD_USUARIO = ?");
			stmt.setString(1, o.getCOD_USUARIO());

			result = stmt.executeQuery();

			while (result.next()) {
				Expense receita = new Expense();
				receita.setCOD_DESPESA(result.getString("COD_DESPESA"));
				receita.setCOD_CATEGORIA_DESPESA(result.getString("COD_CATEGORIA_DESPESA"));
				receita.setDS_VALOR(result.getDouble("DS_VALOR"));
				receita.setNOM_DESPESA(result.getString("NOM_DESPESA"));
				receita.setDS_DATA(result.getDate("DS_DATA"));
				receita.setCOD_USUARIO(result.getString("COD_USUARIO"));
				lista.add(receita);

			}
			return lista;
		} catch (SQLException e) {
			throw new RuntimeException("Erro ao consultar a base de dados", e);
		} finally {

			ConnectionFactory.closeConnection(this.Conn, stmt, result);

		}
	}

	@Override
	public Expense findById(int id) {
		PreparedStatement stmt = null;

		ResultSet result = null;

		try {

			stmt = this.Conn.prepareStatement("SELECT * FROM T_SFF_DESPESAS where COD_DESPESA = ?");
			stmt.setInt(1, id);

			result = stmt.executeQuery();

			if (result.first()) {

				Expense receita = new Expense();
				receita.setCOD_DESPESA(result.getString("COD_DESPESA"));
				receita.setCOD_CATEGORIA_DESPESA(result.getString("COD_CATEGORIA_DESPESA"));
				receita.setDS_VALOR(result.getDouble("DS_VALOR"));
				receita.setNOM_DESPESA(result.getString("NOM_DESPESA"));
				receita.setDS_DATA(result.getDate("DS_DATA"));
				receita.setCOD_USUARIO(result.getString("COD_USUARIO"));

				return receita;
			}
		} catch (SQLException e) {
			throw new RuntimeException("Erro ao consultar a base de dados", e);
		} finally {

			ConnectionFactory.closeConnection(this.Conn, stmt, result);

		}
		return null;
	}

	@Override
	public void delete(int id) {
		PreparedStatement stmt = null;

		ResultSet result = null;

		try {

			stmt = this.Conn.prepareStatement("DELETE  FROM T_SFF_DESPESAS where COD_DESPESA = ?");
			stmt.setInt(1, id);

			stmt.executeUpdate();

		} catch (SQLException e) {
			throw new RuntimeException("Erro ao consultar a base de dados", e);
		} finally {

			ConnectionFactory.closeConnection(this.Conn, stmt, result);

		}

	}

}
