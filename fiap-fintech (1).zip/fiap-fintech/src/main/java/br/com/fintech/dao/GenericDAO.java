package br.com.fintech.dao;

import java.util.List;

import br.com.fintech.bean.User;

public interface GenericDAO<T> {
	public void create(T o);
	public void update(T o);
	public void delete(int id);
	public List<T> read(User o );
	public T findById(int id);

}
