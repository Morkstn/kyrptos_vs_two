package br.com.fintech.security;

import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.sql.Connection;
import java.util.Base64;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

import br.com.fintech.bean.User;

import br.com.fintech.dao.UserDao;

public class UserPassGen {

	public static boolean signUp(User user, Connection conn) throws Exception {
		String salt;
		try {
			salt = getNewSalt();
			String encryptedPassword = getEncryptedPassword(user.getDS_SENHA(), salt);
			user.setDS_SENHA(encryptedPassword);
   
	    user.setDS_SALT(salt); 
			UserDao userdao = new UserDao(conn);
			System.out.println(user);
			userdao.create(user);
   
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;

	}

	public static String getEncryptedPassword(String password, String salt) throws Exception {
		String algorithm = "PBKDF2WithHmacSHA1";
		int derivedKeyLength = 160; // for SHA1
		int iterations = 20000; // NIST specifies 10000

		byte[] saltBytes = Base64.getDecoder().decode(salt);
		KeySpec spec = new PBEKeySpec(password.toCharArray(), saltBytes, iterations, derivedKeyLength);
		SecretKeyFactory f = SecretKeyFactory.getInstance(algorithm);

		byte[] encBytes = f.generateSecret(spec).getEncoded();
		return Base64.getEncoder().encodeToString(encBytes);
	}

	public static String getNewSalt() throws Exception {
		// Don't use Random!
		SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
		// NIST recommends minimum 4 bytes. We use 8.
		byte[] salt = new byte[8];
		random.nextBytes(salt);
		return Base64.getEncoder().encodeToString(salt);
	}

	public static User authenticateUser(String userEmail, String inputPass, Connection conn) throws Exception {

		UserDao userdao = new UserDao(conn);
		User user = userdao.findByEmail(userEmail);
		
		if (user == null) {
			return null;
		}
//		System.out.println("inprimir usuario\n");
//		System.out.println(user.toString());
//		System.out.printf("\ndentro do authenticate",user);
		
		String salt = user.getDS_SALT();
		String calculatedHash = getEncryptedPassword(inputPass, salt);

//		System.out.println( calculatedHash + " : "+user.getDS_SENHA());
		if (calculatedHash.equals(user.getDS_SENHA())) {
			return user;
		} else {
			return null;
		}

	}
}
